angular
    .module('components.weapons', [
        'ui.router'
    ]);