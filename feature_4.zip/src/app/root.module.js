angular
    .module('root', [
        'common',
        'components',
        'templates'
    ]);