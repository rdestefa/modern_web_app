angular
    .module('components.armor', [
        'ui.router'
    ]);