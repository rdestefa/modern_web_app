angular
    .module('components.champions', [
        'ui.router'
    ]);