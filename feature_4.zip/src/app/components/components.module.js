angular
    .module('components', [
        'components.weapons',
        'components.armor',
        'components.champions'
    ]);