function AppController() {
    var ctrl = this;
}

angular
    .module('common')
    .controller('AppController', AppController);